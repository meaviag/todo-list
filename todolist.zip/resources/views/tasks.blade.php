@extends('layouts.app')
@section('title')Задачи @endsection
@section('content')
<h1>nmnrnr</h1>
@endsection