
<?php $__env->startSection('title'); ?>Задачи <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<h1>nmnrnr</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\todolist\resources\views/tasks.blade.php ENDPATH**/ ?>