<?php $__env->startSection('title'); ?>Планировщик времени<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Планировщик</h1>
    <h1>Времени</h1>
    <p>Эффективно управляйте своим временем вместе с нами! Наш сервис поможет вам составить идеальное расписание на день. Никаких больше опозданий и срывов дедлайнов – только продуктивные дни и приятные вечера.</p>
    <a class="btn btn-primary" href="<?php echo e(route('autho')); ?>" role="button">Авторизоваться</a>
    <a class="btn btn-primary" href="<?php echo e(route('registration')); ?>" role="button">Зарегистрироваться</a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\todolist\resources\views/index.blade.php ENDPATH**/ ?>