<?php

use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;

Route::get('/main', function () {
    return view('index');
})->name('home');

Route::get('/tasks', function () {
    return view('tasks');
})->name('tasks');

Route::get('/authorization', function () {
    return view('autho');
})->name('autho');

Route::get('/registration', [UserController::class, 'create'])->name('registration');
Route::post('/registration', [UserController::class, 'store']);

Route::get('/registration/submit', [UserController::class, 'create'])->name('registration');
Route::post('/registration/submit', [UserController::class, 'store']);
