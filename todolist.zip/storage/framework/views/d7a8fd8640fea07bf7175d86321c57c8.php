<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('page.title', config('app.name')); ?></title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.1/css/bootstrap.min.css">
    <?php echo $__env->yieldPushContent('css'); ?>
    <style>
        .container { max-width: 720px; }
        .required:after { content: '*'; color: red; }
    </style>
</head>
<body>
    <div class="d-flex flex-column justify-content-between min-vh-100">

        <?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.0.1/js/bootstrap.min.js"></script>
    <?php echo $__env->yieldPushContent('js'); ?>
</body>
</html><?php /**PATH C:\OSPanel\domains\todolist\resources\views/layouts/base.blade.php ENDPATH**/ ?>